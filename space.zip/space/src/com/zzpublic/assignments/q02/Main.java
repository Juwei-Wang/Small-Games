package com.zzpublic.assignments.q02;

public class Main {
}
