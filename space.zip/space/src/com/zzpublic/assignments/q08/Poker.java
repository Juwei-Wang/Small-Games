package com.zzpublic.assignments.q08;

public class Poker {
    public static void main(String[] args) {
        {
            // 扑克牌的纸牌用数字表示，暂时不考虑扑克的花色问题
            // A 1
            // 2 2
            // 3 3
            // ...
            // 10 10
            // J 11
            // Q 12
            // K 13
            // 假设没有 小王大王牌

            // 代码写在 todo 的位置
        }
        {
            /*
                要求
                    给定 一副手牌
                    判断 是否已经排好序
                    输出 true 或者 false

                背景知识
                    德州扑克的顺序是
                    2 3 4 ... 10 J Q K A

                正确案例
                    1 2 3 4 5 应该是 false
                    2 5 7 9 11 应该是 true
                    2 8 9 13 1 应该是 true
             */

            int[] cards = {1, 2, 3, 4, 5};
            // TODO:

        }
        {
            /*
                要求
                    给定 一副一定升序的手牌
                    判断 是否是顺子
                    输出 true 或者 false

                背景知识
                    德州扑克的顺子是
                    五张牌连在一起

                正确案例
                    1 2 3 4 5 应该是 false
                    2 5 7 9 11 应该是 false
                    6 7 8 9 10 应该是 true
                    10 11 12 13 1 应该是 true
             */
            int[] cards = {2, 3, 4, 5, 6};
            // TODO:

        }
        {
            /*
                要求
                    给定 一副一定升序的手牌
                    判断 是否是葫芦
                    输出 true 或者 false

                背景知识
                    德州扑克的葫芦是
                    三张一样的 + 两张一样的

                正确案例
                    1 2 3 4 5 应该是 false
                    2 2 3 3 4 应该是 false
                    7 7 7 1 1 应该是 true
                    8 8 9 9 9 应该是 true
             */
            int[] cards = {2, 3, 4, 5, 6};
            // TODO:

        }
    }
}
