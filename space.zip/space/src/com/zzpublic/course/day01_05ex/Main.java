package com.zzpublic.course.day01_05ex;

public class Main {
    public static void main(String[] args) {
        //  >   3
        //  >   4
        //  <   12




    }
}
