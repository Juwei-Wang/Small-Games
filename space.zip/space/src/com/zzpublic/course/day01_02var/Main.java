package com.zzpublic.course.day01_02var;

public class Main {
    public static void main(String[] args) {
        String name = "ZZPublic";
        System.out.println("abc");
        System.out.println(name);
        System.out.println(name);

        int count = 1;
        double price = 1.2;
        String message = "欢迎";


        // ---

        int age = 10;
        System.out.println(age);

        double ticketPrice = 0.8;
        System.out.println(ticketPrice);

        double averageWaitingTime = 3.7;
        System.out.println(averageWaitingTime);

        double ping2Jun1Deng3Dai4Shi2Jian1 = 3.7;
        System.out.println(ping2Jun1Deng3Dai4Shi2Jian1);

        int clhs = 2; // 处理函数

        int numstr = 2; // 字符串的数量 // number of string


        System.out.println(1 + 2);
        System.out.println(1 * 2);
        System.out.println("1" + "2");
//        System.out.println("1" * "2");
        System.out.println("1 + 2");


        int intVariable1 = 3;
//        int intVariable2 = 3.0; // 错！
//        int intVariable2 = "3.0"; // 错！

        System.out.println(intVariable1);

        double doubleVar1 = 3; // int
        System.out.println(doubleVar1);

        int intVar1 = (int)3.9;
        System.out.println(intVar1);

        byte byteVar1 = (byte)256;
        System.out.println(byteVar1);




    }
}