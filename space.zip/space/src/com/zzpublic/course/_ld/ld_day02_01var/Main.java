package com.zzpublic.course._ld.ld_day02_01var;

public class Main {
    public static void main(String[] args) {

        String name = "ZZPublic";
        System.out.println(name);
        System.out.println(name);
        System.out.println(name);

        int count = 1;
        double price = 1.2;
        String message = "欢迎";

        int age = 10;
        System.out.println(age);

        double doubleVar = 1;
        System.out.println(doubleVar);

        int intVar = (int)1.9;
        // literal, 字面量
        System.out.println(intVar);

    }
}
