package com.zzpublic.course._ld.ld_day03_02if;

import com.zzpublic.console.Console;

public class Main {
    public static void main(String[] args) {
        int price = 9;
        boolean addRice = true;
        if (5 < 3) {
            price += 1;
        }
        Console.println("有人加米饭啦");
        Console.println(price);


        // x *= x < 0 ? -1 : 1;
    }
}
