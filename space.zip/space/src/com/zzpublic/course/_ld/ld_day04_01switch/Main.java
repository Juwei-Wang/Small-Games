package com.zzpublic.course._ld.ld_day04_01switch;

import com.zzpublic.console.Console;

public class Main {
    public static void main(String[] args) {
        int x = 0;
        switch (x) {
            case 0:
            Console.println("x");
            break;
            case 1:
            Console.println("o");
            break;
            case 2:
            Console.println("=");
            break;
        }
    }
}
