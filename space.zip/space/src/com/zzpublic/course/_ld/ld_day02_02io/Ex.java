package com.zzpublic.course._ld.ld_day02_02io;

import com.zzpublic.console.Console;

public class Ex {
    public static void main(String[] args) {
        int a = 3;
        int b = 4;
        Console.println(a + b);


        /*

        >   8
        >   9
        <   17

         */
    }
}
