package com.zzpublic.course._ld.ld_day02_02io;

import com.zzpublic.console.Console;

public class Main {
    public static void main(String[] args) {
        int price = Console.readInt();
        Console.println("总价：" + price);
        Console.println("您需支付：" + price);


    }
}
