package com.zzpublic.course.day01_03io;

import com.zzpublic.console.Console;

public class Main {
    public static void main(String[] args) {
        int a = 1;
        double b = 1.0;
        System.out.print(a);
        System.out.println(b);
        Console.print(a);
        Console.println(a);

//        int value = Console.readInt();
//        Console.println(value);
//        Console.println(value);

        int value = Console.readInt();
        Console.println(value);


    }
}
