package com.zzpublic.course.day01_01hello;

public class Demo {
    public static void main(String[] args) {
        // 我人生的第一个java 代码，萌萌哒。摔桌子
        // 123
        System.out.println("Hello, World");
        System.out.println("Hello, ZZ");
//        System.out.println("Hello, ZZ2");
        System.out.println("Hello, ZZ1");
        System.out.println("Hello, ZZ3");

        /*
         *
         * ╰（‵□′）╯╰（‵□′）╯
         *
         */
    }
}
